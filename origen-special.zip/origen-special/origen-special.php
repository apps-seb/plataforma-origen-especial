<?php
/**
 * Plugin Name: Origen SPECIAL Agro Platform
 * Description: Plataforma tipo app para caficultores.
 * Version: 1.0.0
 * Author: Tu Nombre
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// 1. ACTIVACIÓN DEL PLUGIN
register_activation_hook( __FILE__, 'origen_special_activate' );
function origen_special_activate() {
    // Crear rol si no existe
    if ( ! get_role( 'caficultor' ) ) {
        add_role( 'caficultor', 'Caficultor', array( 'read' => true ) );
    }

    // Crear página /caficultores si no existe
    $page = get_page_by_path( 'caficultores' );
    if ( ! $page ) {
        wp_insert_post( array(
            'post_title'   => 'Caficultores',
            'post_name'    => 'caficultores',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ) );
    }
}

// 2. ENQUEUE SCRIPTS & STYLES
add_action( 'wp_enqueue_scripts', 'origen_special_assets' );
function origen_special_assets() {
    if ( is_page( 'caficultores' ) ) {
        wp_enqueue_style( 'origen-style', plugin_dir_url( __FILE__ ) . 'assets/css/style.css', array(), '1.0.0' );
        wp_enqueue_script( 'origen-js', plugin_dir_url( __FILE__ ) . 'assets/js/app.js', array(), '1.0.0', true );
        wp_localize_script( 'origen-js', 'origenApp', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'origen_auth_nonce' )
        ) );
    }
}

// 3. INTERCEPTAR PLANTILLA
add_filter( 'template_include', 'origen_special_template' );
function origen_special_template( $template ) {
    if ( is_page( 'caficultores' ) ) {
        $plugin_template = plugin_dir_path( __FILE__ ) . 'templates/app-layout.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
    }
    return $template;
}

// 4. SHORTCODE: REGISTRO/LOGIN
add_shortcode( 'origen_special_register', 'origen_special_register_html' );
function origen_special_register_html() {
    ob_start(); ?>
    <div class="origen-auth-box">
        <div class="origen-tabs">
            <button class="origen-tab-btn active" data-target="login">Iniciar Sesión</button>
            <button class="origen-tab-btn" data-target="register">Registrarse</button>
        </div>

        <form id="origen-login-form" class="origen-form active">
            <div class="origen-input-group">
                <label for="log_user">Email o Usuario</label>
                <input type="text" id="log_user" required>
            </div>
            <div class="origen-input-group">
                <label for="log_pass">Contraseña</label>
                <input type="password" id="log_pass" required>
            </div>
            <button type="submit" class="origen-btn">Entrar</button>
        </form>

        <form id="origen-register-form" class="origen-form" style="display: none;">
            <div class="origen-input-group">
                <label for="reg_name">Nombre Completo</label>
                <input type="text" id="reg_name" required>
            </div>
            <div class="origen-input-group">
                <label for="reg_email">Email</label>
                <input type="email" id="reg_email" required>
            </div>
            <div class="origen-input-group">
                <label for="reg_pass">Contraseña</label>
                <input type="password" id="reg_pass" required>
            </div>
            <button type="submit" class="origen-btn">Crear Cuenta</button>
        </form>

        <div id="origen-msg" class="origen-msg"></div>
    </div>
    <?php
    return ob_get_clean();
}

// 5. SHORTCODE: DASHBOARD
add_shortcode( 'origen_special_dashboard', 'origen_special_dashboard_html' );
function origen_special_dashboard_html() {
    $current_user = wp_get_current_user();
    ob_start(); ?>
    <div class="origen-dashboard">
        <h2>Bienvenido, <?php echo esc_html( $current_user->display_name ); ?> 👋</h2>
        <div class="origen-grid">
            <button class="origen-card-btn">🌱 Mi Finca</button>
            <button class="origen-card-btn">📊 Calcular Producción</button>
            <button class="origen-card-btn">🛒 Ver Tienda</button>
            <a href="<?php echo esc_url( wp_logout_url( site_url( '/caficultores' ) ) ); ?>" class="origen-btn-outline">Cerrar Sesión</a>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// 6. LÓGICA AJAX: REGISTRO
add_action( 'wp_ajax_nopriv_origen_register_action', 'origen_ajax_register' );
function origen_ajax_register() {
    check_ajax_referer( 'origen_auth_nonce', 'nonce' );

    $name  = sanitize_text_field( $_POST['name'] );
    $email = sanitize_email( $_POST['email'] );
    $pass  = $_POST['pass'];

    if ( email_exists( $email ) ) {
        wp_send_json_error( 'El correo ya está registrado.' );
    }

    $user_id = wp_insert_user( array(
        'user_login' => $email,
        'user_pass'  => $pass,
        'user_email' => $email,
        'first_name' => $name,
        'display_name' => $name,
        'role'       => 'caficultor'
    ) );

    if ( is_wp_error( $user_id ) ) {
        wp_send_json_error( $user_id->get_error_message() );
    }

    // Auto-login
    wp_set_current_user( $user_id );
    wp_set_auth_cookie( $user_id );
    
    wp_send_json_success( 'Cuenta creada. Entrando...' );
}

// 7. LÓGICA AJAX: LOGIN
add_action( 'wp_ajax_nopriv_origen_login_action', 'origen_ajax_login' );
function origen_ajax_login() {
    check_ajax_referer( 'origen_auth_nonce', 'nonce' );

    $user = sanitize_text_field( $_POST['user'] );
    $pass = $_POST['pass'];

    $creds = array(
        'user_login'    => $user,
        'user_password' => $pass,
        'remember'      => true
    );

    $user_signon = wp_signon( $creds, false );

    if ( is_wp_error( $user_signon ) ) {
        wp_send_json_error( 'Usuario o contraseña incorrectos.' );
    }

    wp_send_json_success( 'Acceso correcto. Cargando dashboard...' );
}