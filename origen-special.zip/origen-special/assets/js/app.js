document.addEventListener('DOMContentLoaded', () => {
    
    // Control de Pestañas
    const tabs = document.querySelectorAll('.origen-tab-btn');
    const forms = document.querySelectorAll('.origen-form');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            forms.forEach(f => f.style.display = 'none');
            
            tab.classList.add('active');
            document.getElementById(`origen-${tab.dataset.target}-form`).style.display = 'block';
            hideMsg();
        });
    });

    const msgBox = document.getElementById('origen-msg');

    function showMsg(text, type) {
        if(!msgBox) return;
        msgBox.textContent = text;
        msgBox.className = `origen-msg ${type}`;
    }

    function hideMsg() {
        if(!msgBox) return;
        msgBox.className = 'origen-msg';
        msgBox.textContent = '';
    }

    function handleAjaxRequest(action, dataObj) {
        showMsg('Procesando...', 'loading');

        const formData = new URLSearchParams();
        formData.append('action', action);
        formData.append('nonce', origenApp.nonce);
        
        for (const key in dataObj) {
            formData.append(key, dataObj[key]);
        }

        fetch(origenApp.ajax_url, {
            method: 'POST',
            body: formData,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        })
        .then(res => res.json())
        .then(res => {
            if (res.success) {
                showMsg(res.data, 'success');
                setTimeout(() => window.location.reload(), 1500);
            } else {
                showMsg(res.data, 'error');
            }
        })
        .catch(err => {
            showMsg('Error de conexión', 'error');
        });
    }

    // Submit Login
    const loginForm = document.getElementById('origen-login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                user: document.getElementById('log_user').value,
                pass: document.getElementById('log_pass').value
            };
            handleAjaxRequest('origen_login_action', data);
        });
    }

    // Submit Register
    const registerForm = document.getElementById('origen-register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                name: document.getElementById('reg_name').value,
                email: document.getElementById('reg_email').value,
                pass: document.getElementById('reg_pass').value
            };
            handleAjaxRequest('origen_register_action', data);
        });
    }
});