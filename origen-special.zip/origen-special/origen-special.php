<?php
/**
 * Plugin Name: Origen SPECIAL Agro Platform
 * Description: Plataforma tipo app premium para la cadena de valor del café. Tienda Inteligente.
 * Version: 4.2.0 (Diseño Tienda y Scroll)
 * Author: Tu Nombre
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ========================================================================
// 1. ACTIVACIÓN DEL PLUGIN Y REGISTRO DE OPCIONES
// ========================================================================
register_activation_hook( __FILE__, 'origen_special_activate' );
function origen_special_activate() {
    $roles = array(
        'caficultor' => 'Caficultor',
        'asociacion_cafe' => 'Asociación de Caficultores',
        'comprador_cafe' => 'Comprador de Café'
    );
    
    foreach ($roles as $slug => $name) { 
        if ( ! get_role( $slug ) ) {
            add_role( $slug, $name, array( 'read' => true ) ); 
        }
    }

    if ( ! get_page_by_path( 'caficultores' ) ) { 
        wp_insert_post( array( 
            'post_title'  => 'Caficultores', 
            'post_name'   => 'caficultores', 
            'post_status' => 'publish', 
            'post_type'   => 'page' 
        ) ); 
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'origen_fincas';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT, 
        user_id bigint(20) NOT NULL, 
        nombre_finca varchar(255) NOT NULL,
        ubicacion varchar(255) NOT NULL, 
        altura int(11) DEFAULT 0, 
        hectareas float DEFAULT 0, 
        cantidad_plantas int(11) DEFAULT 0,
        variedad_cafe varchar(100) DEFAULT '', 
        edad_cultivo int(11) DEFAULT 0, 
        densidad_siembra int(11) DEFAULT 0,
        tipo_sombra varchar(50) DEFAULT '', 
        sistema_cultivo varchar(50) DEFAULT '', 
        fecha_registro datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id), 
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' ); 
    dbDelta( $sql );
}

add_action( 'admin_init', 'origen_special_register_settings' );
function origen_special_register_settings() {
    register_setting( 'origen_special_settings_group', 'origen_precio_manual' );
    register_setting( 'origen_special_settings_group', 'origen_owm_api_key' );
    register_setting( 'origen_special_settings_group', 'origen_descuento_caficultor' ); 
}

// ========================================================================
// 2. FUNCIONES NÚCLEO: APIs EN TIEMPO REAL (CON CACHÉ)
// ========================================================================
function get_precio_cafe_actual() {
    $precio_cache = get_transient( 'origen_precio_cafe' );
    if ( false !== $precio_cache ) {
        return $precio_cache;
    }

    $precio_fallback = get_option( 'origen_precio_manual', 12000 );
    $precio_final = $precio_fallback;

    $api_url = 'https://api.origen-special.com/v1/precio-cafe'; 
    $response = wp_remote_get( $api_url, array('timeout' => 3) );

    if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );
        if ( isset($data['precio_kg']) && is_numeric($data['precio_kg']) ) {
            $precio_final = floatval($data['precio_kg']);
        }
    }

    set_transient( 'origen_precio_cafe', $precio_final, HOUR_IN_SECONDS );
    return $precio_final;
}

function get_clima_finca( $ubicacion ) {
    if ( empty($ubicacion) ) {
        return false;
    }
    
    $transient_key = 'origen_clima_' . md5($ubicacion);
    $clima_cache = get_transient( $transient_key );
    if ( false !== $clima_cache ) {
        return $clima_cache;
    }

    $api_key = get_option( 'origen_owm_api_key', '' );
    if ( empty($api_key) ) {
        return false;
    }

    $ciudad = explode(',', $ubicacion)[0];
    $ciudad_url = urlencode( trim($ciudad) . ',CO' );

    $url = "https://api.openweathermap.org/data/2.5/weather?q={$ciudad_url}&units=metric&appid={$api_key}&lang=es";
    $response = wp_remote_get( $url, array('timeout' => 5) );

    if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
        return false;
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( !isset($body['main']['temp']) ) {
        return false;
    }

    $datos_clima = array(
        'temp'        => round($body['main']['temp']),
        'humedad'     => $body['main']['humidity'],
        'descripcion' => ucfirst($body['weather'][0]['description']),
        'icono'       => $body['weather'][0]['icon']
    );

    set_transient( $transient_key, $datos_clima, HOUR_IN_SECONDS );
    return $datos_clima;
}

// ========================================================================
// 3. WOOCOMMERCE: DESCUENTOS POR ROL
// ========================================================================
add_filter( 'woocommerce_product_get_price', 'origen_descuento_rol_caficultor', 99, 2 );
add_filter( 'woocommerce_product_variation_get_price', 'origen_descuento_rol_caficultor', 99, 2 );
function origen_descuento_rol_caficultor( $price, $product ) {
    if ( is_user_logged_in() ) {
        $user = wp_get_current_user();
        if ( in_array( 'caficultor', (array) $user->roles ) ) {
            $descuento = floatval( get_option('origen_descuento_caficultor', 10) );
            if ( $descuento > 0 && $descuento <= 100 ) {
                return $price - ( $price * ( $descuento / 100 ) );
            }
        }
    }
    return $price;
}

// ========================================================================
// 4. ENQUEUE SCRIPTS & INTERCEPTAR PLANTILLA
// ========================================================================
add_action( 'wp_enqueue_scripts', 'origen_special_assets' );
function origen_special_assets() {
    if ( is_page( 'caficultores' ) ) {
        wp_enqueue_style( 'origen-style', plugin_dir_url( __FILE__ ) . 'assets/css/style.css', array(), '4.2.0' );
        wp_enqueue_script( 'origen-js', plugin_dir_url( __FILE__ ) . 'assets/js/app.js', array('jquery'), '4.2.0', true );
        
        wp_localize_script( 'origen-js', 'origenApp', array(
            'ajax_url'      => admin_url( 'admin-ajax.php' ),
            'nonce'         => wp_create_nonce( 'origen_auth_nonce' ),
            'dashboard_url' => site_url( '/caficultores/' ),
            'precio_actual' => get_precio_cafe_actual()
        ) );
    }
}

add_filter( 'template_include', 'origen_special_template' );
function origen_special_template( $template ) {
    if ( is_page( 'caficultores' ) ) {
        nocache_headers(); 
        $plugin_template = plugin_dir_path( __FILE__ ) . 'templates/app-layout.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
    }
    return $template;
}

// ========================================================================
// 5. SHORTCODE: REGISTRO / LOGIN
// ========================================================================
add_shortcode( 'origen_special_register', 'origen_special_register_html' );
function origen_special_register_html() {
    ob_start(); ?>
    <div class="origen-auth-box">
        <div class="origen-tabs">
            <button class="origen-tab-btn active" data-target="login">
                <i class="ph ph-sign-in"></i> Ingresar
            </button>
            <button class="origen-tab-btn" data-target="register">
                <i class="ph ph-user-plus"></i> Crear Cuenta
            </button>
        </div>

        <form id="origen-login-form" class="origen-form active">
            <div class="origen-input-group">
                <label>Email o Usuario</label>
                <div class="input-with-icon">
                    <i class="ph ph-envelope-simple"></i>
                    <input type="text" id="log_user" required>
                </div>
            </div>
            <div class="origen-input-group">
                <label>Contraseña</label>
                <div class="input-with-icon">
                    <i class="ph ph-lock-key"></i>
                    <input type="password" id="log_pass" required>
                    <button type="button" class="toggle-pass" tabindex="-1"><i class="ph ph-eye"></i></button>
                </div>
            </div>
            <button type="submit" class="origen-btn"><i class="ph ph-arrow-right"></i> Acceder</button>
        </form>

        <form id="origen-register-form" class="origen-form" style="display: none;">
            <div class="origen-grid-2">
                <div class="origen-input-group">
                    <label>Nombre(s)</label>
                    <input type="text" id="reg_name" required>
                </div>
                <div class="origen-input-group">
                    <label>Apellido(s)</label>
                    <input type="text" id="reg_lastname" required>
                </div>
            </div>

            <div class="origen-grid-2">
                <div class="origen-input-group">
                    <label>Cédula o C. Cafetera</label>
                    <input type="number" id="reg_id_number" required>
                </div>
                <div class="origen-input-group">
                    <label>Perfil</label>
                    <select id="reg_role" required>
                        <option value="">Selecciona...</option>
                        <option value="caficultor">Caficultor / Productor</option>
                        <option value="asociacion_cafe">Asociación</option>
                        <option value="comprador_cafe">Comprador</option>
                    </select>
                </div>
            </div>

            <div id="cond_caficultor" class="origen-conditional-fields" style="display:none;">
                <div class="origen-grid-2">
                    <div class="origen-input-group">
                        <label>Nombre de la Finca</label>
                        <input type="text" id="reg_finca">
                    </div>
                    <div class="origen-input-group">
                        <label>Tamaño</label>
                        <select id="reg_tamano_prod">
                            <option value="pequeno">Pequeño Productor</option>
                            <option value="mediano">Mediano Productor</option>
                            <option value="grande">Grande Productor</option>
                        </select>
                    </div>
                </div>
            </div>

            <div id="cond_asociacion" class="origen-conditional-fields" style="display:none;">
                <div class="origen-input-group">
                    <label>Asociación</label>
                    <select id="reg_asoc_lista">
                        <option value="">Seleccionar...</option>
                        <option value="Caficauca">Caficauca</option>
                        <option value="Cosurca">Cosurca</option>
                        <option value="Fondo Paez">Fondo Paez</option>
                        <option value="Nuevo Futuro">Nuevo Futuro</option>
                        <option value="Cencoic">Cencoic</option>
                        <option value="otra">Otra (Escribir)</option>
                    </select>
                </div>
                <div class="origen-input-group" id="wrap_otra_asoc" style="display:none;">
                    <label>Nombre</label>
                    <input type="text" id="reg_asoc_otra">
                </div>
            </div>

            <div id="cond_comprador" class="origen-conditional-fields" style="display:none;">
                <div class="origen-input-group">
                    <label>Tipo de Comprador</label>
                    <select id="reg_tipo_comprador">
                        <option value="comprador_local">Comprador Local</option>
                        <option value="comercializador">Comercializador</option>
                        <option value="tostador">Tostador</option>
                        <option value="exportador">Exportador</option>
                    </select>
                </div>
            </div>

            <div class="origen-grid-2">
                <div class="origen-input-group">
                    <label>Departamento</label>
                    <select id="reg_depto" required>
                        <option value="">Seleccione...</option>
                        <option value="Cauca">Cauca</option>
                        <option value="Huila">Huila</option>
                        <option value="Nariño">Nariño</option>
                        <option value="Antioquia">Antioquia</option>
                    </select>
                </div>
                <div class="origen-input-group">
                    <label>Municipio</label>
                    <select id="reg_muni" required>
                        <option value="">Depto primero</option>
                    </select>
                </div>
            </div>

            <div class="origen-input-group">
                <label>Correo Electrónico</label>
                <div class="input-with-icon">
                    <i class="ph ph-envelope-simple"></i>
                    <input type="email" id="reg_email" required>
                </div>
            </div>

            <div class="origen-input-group">
                <label>Contraseña <span class="hint">(Mín. 8 caracteres)</span></label>
                <div class="input-with-icon">
                    <i class="ph ph-lock-key"></i>
                    <input type="password" id="reg_pass" required minlength="8">
                    <button type="button" class="toggle-pass" tabindex="-1"><i class="ph ph-eye"></i></button>
                </div>
            </div>

            <button type="submit" class="origen-btn"><i class="ph ph-check-circle"></i> Registrarse</button>
        </form>
        <div id="origen-msg" class="origen-msg"></div>
    </div>
    <?php return ob_get_clean();
}

// ========================================================================
// 6. SHORTCODE: FINCA (CRUD)
// ========================================================================
add_shortcode( 'origen_special_finca', 'origen_special_finca_html' );
function origen_special_finca_html() {
    if ( ! is_user_logged_in() ) return '';
    
    global $wpdb; 
    $user_id = get_current_user_id(); 
    $table_name = $wpdb->prefix . 'origen_fincas';
    $finca = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE user_id = %d", $user_id ) );
    
    $val_nombre = $finca ? $finca->nombre_finca : get_user_meta($user_id, 'nombre_finca', true);
    $val_ubic = $finca ? $finca->ubicacion : (get_user_meta($user_id, 'municipio', true) . ', ' . get_user_meta($user_id, 'departamento', true));
    
    ob_start(); ?>
    <form id="origen-finca-form">
        <div class="origen-input-group">
            <label>Nombre de la Finca</label>
            <input type="text" id="finca_nombre" value="<?php echo esc_attr($val_nombre); ?>" required>
        </div>
        <div class="origen-input-group">
            <label>Ubicación (Municipio, Departamento)</label>
            <input type="text" id="finca_ubicacion" value="<?php echo esc_attr($val_ubic); ?>" required>
        </div>
        
        <div class="origen-grid-2">
            <div class="origen-input-group">
                <label>Altura (m.s.n.m)</label>
                <input type="number" id="finca_altura" value="<?php echo $finca ? esc_attr($finca->altura) : ''; ?>" required>
            </div>
            <div class="origen-input-group">
                <label>Hectáreas Totales</label>
                <input type="number" step="0.01" id="finca_hectareas" value="<?php echo $finca ? esc_attr($finca->hectareas) : ''; ?>" required>
            </div>
        </div>
        
        <div class="origen-grid-2">
            <div class="origen-input-group">
                <label>Cantidad de Plantas</label>
                <input type="number" id="finca_plantas" value="<?php echo $finca ? esc_attr($finca->cantidad_plantas) : ''; ?>" required>
            </div>
            <div class="origen-input-group">
                <label>Densidad (Plantas/ha)</label>
                <input type="number" id="finca_densidad" value="<?php echo $finca ? esc_attr($finca->densidad_siembra) : ''; ?>">
            </div>
        </div>
        
        <div class="origen-grid-2">
            <div class="origen-input-group">
                <label>Variedad Principal</label>
                <select id="finca_variedad" required>
                    <?php 
                    $variedades = ['Castillo', 'Caturra', 'Colombia', 'Typica', 'Bourbon', 'Geisha', 'Tabi', 'Otra']; 
                    foreach($variedades as $var) { 
                        $sel = ($finca && $finca->variedad_cafe === $var) ? 'selected' : ''; 
                        echo "<option value='$var' $sel>$var</option>"; 
                    } 
                    ?>
                </select>
            </div>
            <div class="origen-input-group">
                <label>Edad del Cultivo (Años)</label>
                <input type="number" id="finca_edad" value="<?php echo $finca ? esc_attr($finca->edad_cultivo) : ''; ?>" required>
            </div>
        </div>
        
        <div class="origen-grid-2">
            <div class="origen-input-group">
                <label>Tipo de Sombra</label>
                <select id="finca_sombra" required>
                    <option value="Libre exposición" <?php if($finca && $finca->tipo_sombra == 'Libre exposición') echo 'selected'; ?>>Libre exposición</option>
                    <option value="Sombra parcial" <?php if($finca && $finca->tipo_sombra == 'Sombra parcial') echo 'selected'; ?>>Sombra parcial</option>
                    <option value="Sombra densa" <?php if($finca && $finca->tipo_sombra == 'Sombra densa') echo 'selected'; ?>>Sombra densa</option>
                </select>
            </div>
            <div class="origen-input-group">
                <label>Sistema de Cultivo</label>
                <select id="finca_sistema" required>
                    <option value="Tradicional" <?php if($finca && $finca->sistema_cultivo == 'Tradicional') echo 'selected'; ?>>Tradicional</option>
                    <option value="Tecnificado" <?php if($finca && $finca->sistema_cultivo == 'Tecnificado') echo 'selected'; ?>>Tecnificado</option>
                    <option value="Orgánico" <?php if($finca && $finca->sistema_cultivo == 'Orgánico') echo 'selected'; ?>>Orgánico Certificado</option>
                </select>
            </div>
        </div>
        
        <button type="submit" class="origen-btn"><i class="ph ph-floppy-disk"></i> Guardar Perfil</button>
        <div id="origen-finca-msg" class="origen-msg"></div>
    </form>
    <?php return ob_get_clean();
}

// ========================================================================
// 7. SHORTCODE: MOTOR DE PRODUCCIÓN 
// ========================================================================
add_shortcode( 'origen_special_produccion', 'origen_special_produccion_html' );
function origen_special_produccion_html() {
    if ( ! is_user_logged_in() ) return '';
    $precio_mercado = get_precio_cafe_actual();
    ob_start(); ?>
    <div class="origen-calc-wrapper">
        <div class="origen-tabs sub-tabs">
            <button class="origen-tab-btn active" data-target="calc-auto">
                <i class="ph ph-database"></i> Mi Cosecha Base
            </button>
            <button class="origen-tab-btn" data-target="calc-sim">
                <i class="ph ph-sliders"></i> Simulador Dinámico
            </button>
        </div>

        <div id="origen-calc-auto-form" class="origen-form active">
            <div class="realtime-data-panel">
                <div class="rt-card market-rt">
                    <i class="ph ph-trend-up"></i>
                    <div>
                        <span>Precio Referencia</span>
                        <strong>$<?php echo number_format($precio_mercado, 0, ',', '.'); ?> <small>COP/kg</small></strong>
                    </div>
                </div>
                <div class="rt-card weather-rt" id="weather-widget">
                    <i class="ph ph-cloud-sun"></i>
                    <div>
                        <span>Clima en Finca</span>
                        <strong id="weather-text">Consultando...</strong>
                    </div>
                </div>
            </div>
            
            <p style="color:var(--text-muted); font-size:14px; margin-bottom:20px;">Estima tu producción anual con los datos de tu finca y el precio actual.</p>
            <button id="btn-calcular-cosecha" class="origen-btn"><i class="ph ph-math-operations"></i> Calcular Producción Base</button>
            <div id="origen-calc-msg" class="origen-msg"></div>
            
            <div id="origen-calc-results" style="display:none; margin-top:30px;">
                <div class="calc-indicator-box">
                    <div class="calc-header">
                        <h4>Rendimiento Actual:</h4>
                        <span id="res-indicador" class="badge-rendimiento">...</span>
                    </div>
                    <div class="progress-bar-bg"><div id="res-bar" class="progress-bar-fill"></div></div>
                </div>
                <div class="origen-grid-3">
                    <div class="calc-card">
                        <i class="ph ph-scales"></i>
                        <h5>Producción Anual</h5>
                        <div><strong id="res-kg">0</strong> <small>kg</small></div>
                    </div>
                    <div class="calc-card">
                        <i class="ph ph-package"></i>
                        <h5>Sacos (60kg)</h5>
                        <div><strong id="res-sacos">0</strong> <small>und</small></div>
                    </div>
                    <div class="calc-card highlight">
                        <i class="ph ph-currency-circle-dollar"></i>
                        <h5>Valor Estimado</h5>
                        <div><strong id="res-valor">0</strong> <small>COP</small></div>
                    </div>
                </div>
            </div>
        </div>

        <div id="origen-calc-sim-form" class="origen-form" style="display: none;">
            <div class="simulador-controles">
                <div class="origen-input-group">
                    <label>Plantas Productivas: <span id="val-sim-plantas" class="sim-val">5000</span></label>
                    <input type="range" id="sim_plantas" min="1000" max="50000" step="500" value="5000">
                </div>
                <div class="origen-grid-2">
                    <div class="origen-input-group">
                        <label>Variedad</label>
                        <select id="sim_variedad">
                            <option value="1.0">Castillo / Colombia</option>
                            <option value="0.9">Caturra</option>
                            <option value="0.85">Bourbon</option>
                        </select>
                    </div>
                    <div class="origen-input-group">
                        <label>Sistema</label>
                        <select id="sim_sistema">
                            <option value="1.0">Tecnificado</option>
                            <option value="0.8">Tradicional</option>
                        </select>
                    </div>
                </div>
                <div class="origen-grid-2">
                    <div class="origen-input-group">
                        <label>Humedad del Grano: <span id="val-sim-humedad" class="sim-val">12%</span></label>
                        <input type="range" id="sim_humedad" min="10" max="25" step="1" value="12">
                        <span class="hint" id="hint-humedad">Humedad óptima CPS (10%-12%)</span>
                    </div>
                    <div class="origen-input-group">
                        <label>Precio (COP/Kg)</label>
                        <input type="number" id="sim_precio" value="<?php echo esc_attr($precio_mercado); ?>" step="500">
                    </div>
                </div>
            </div>
            
            <div class="origen-grid-3" style="margin-top: 25px;">
                <div class="calc-card">
                    <i class="ph ph-scales"></i>
                    <h5>Producción Útil</h5>
                    <div><strong id="sim-res-kg">0</strong> <small>kg</small></div>
                </div>
                <div class="calc-card">
                    <i class="ph ph-package"></i>
                    <h5>Sacos</h5>
                    <div><strong id="sim-res-sacos">0</strong> <small>und</small></div>
                </div>
                <div class="calc-card highlight">
                    <i class="ph ph-currency-circle-dollar"></i>
                    <h5>Ingreso Estimado</h5>
                    <div><strong id="sim-res-valor">0</strong> <small>COP</small></div>
                </div>
            </div>
        </div>
    </div>
    <?php return ob_get_clean();
}

// ========================================================================
// 8. SHORTCODE: TIENDA WOOCOMMERCE INTELIGENTE Y RECOMENDACIONES PRECISAS
// ========================================================================
add_shortcode( 'origen_special_tienda', 'origen_special_tienda_html' );
function origen_special_tienda_html() {
    if ( ! is_user_logged_in() ) {
        return '<div class="origen-msg error" style="display:block;">Debes iniciar sesión para ver la tienda.</div>';
    }
    if ( ! class_exists( 'WooCommerce' ) ) {
        return '<div class="origen-msg error" style="display:block;">La tienda está en mantenimiento (WooCommerce inactivo).</div>';
    }
    
    global $wpdb;
    $user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'origen_fincas';
    $finca = $wpdb->get_row( $wpdb->prepare( "SELECT hectareas, cantidad_plantas FROM $table_name WHERE user_id = %d", $user_id ) );
    
    $hectareas = $finca ? floatval($finca->hectareas) : 0;
    $plantas = $finca ? intval($finca->cantidad_plantas) : 0;
    
    // Categorías en WooCommerce
    $categorias = array('fertilizantes', 'herramientas', 'insumos-agricolas', 'abonos');
    
    // LÓGICA DE DIAGNÓSTICO: Nombres específicos y amigables.
    if ( $hectareas > 0 ) {
        $bultos_fert = ceil($hectareas * 12); 
        $kg_abono = ceil($plantas * 0.5); 
        
        $sugerencia_msg = "
        <div class='recomendacion-box'>
            <div class='recom-title'><i class='ph ph-sparkle'></i> Recomendación Técnica de Cultivo</div>
            <p>Para tu finca de <strong>{$hectareas} hectáreas</strong> ({$plantas} plantas), te sugerimos aplicar por ciclo:</p>
            <ul>
                <li>🌱 <strong>{$bultos_fert} bultos (50kg)</strong> de Fertilizante (Ej: Triple 15, Producción o Agrimins).</li>
                <li>🍂 <strong>{$kg_abono} kg</strong> de Abono Orgánico (Ej: Compost, Humus o Gallinaza).</li>
                <li>🛡️ <strong>Preventivos:</strong> Fungicidas (Ej: Mancozeb, Nativo) para control de roya.</li>
            </ul>
            <p><small>Busca estos productos o equivalentes en la tienda con tu descuento aplicado.</small></p>
        </div>";
    } else {
        $sugerencia_msg = "<div class='recomendacion-box'><div class='recom-title'><i class='ph ph-info'></i> Información</div><p>💡 Completa los datos de 'Mi Finca' para recibir recomendaciones exactas de productos y cantidades basadas en tu hectariaje.</p></div>";
    }

    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => 10,
        'post_status'    => 'publish',
        'tax_query'      => array(
            array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => $categorias,
                'operator' => 'IN'
            )
        )
    );
    
    $loop = new WP_Query( $args );
    
    ob_start(); ?>
    <div class="origen-tienda-wrapper">
        
        <?php echo $sugerencia_msg; ?>
        
        <?php if ( $loop->have_posts() ) : ?>
            <div class="origen-store-grid">
                <?php while ( $loop->have_posts() ) : $loop->the_post(); 
                    global $product;
                    $regular_price = $product->get_regular_price();
                    $sale_price = $product->get_price(); 
                ?>
                    <div class="origen-product-card">
                        <div class="product-img-box">
                            <?php echo $product->get_image('woocommerce_thumbnail'); ?>
                            <?php if($regular_price > $sale_price): ?>
                                <span class="discount-badge">-10% Asociado</span>
                            <?php endif; ?>
                        </div>
                        <div class="product-info">
                            <h4 class="product-title"><?php echo get_the_title(); ?></h4>
                            <div class="price-box">
                                <?php if($regular_price > $sale_price): ?>
                                    <del><?php echo wc_price($regular_price); ?></del>
                                <?php endif; ?>
                                <strong><?php echo wc_price($sale_price); ?></strong>
                            </div>
                            
                            <div class="origen-qty-cart">
                                <input type="number" class="origen-qty-input" value="1" min="1" step="1" data-target-btn="<?php echo esc_attr($product->get_id()); ?>">
                                <a href="?add-to-cart=<?php echo esc_attr($product->get_id()); ?>" data-quantity="1" class="origen-btn-buy button add_to_cart_button ajax_add_to_cart" id="btn-add-<?php echo esc_attr($product->get_id()); ?>" data-product_id="<?php echo esc_attr($product->get_id()); ?>">
                                    <i class="ph ph-shopping-cart"></i> Añadir
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <div class="origen-msg error" style="display:block; text-align:left;">
                <i class="ph ph-warning-circle" style="font-size:24px; margin-bottom:10px; display:block;"></i>
                <strong>La tienda aún no tiene productos vinculados.</strong><br><br>
                Para ver productos aquí, ve a <b>WordPress > Productos</b> y asígnales alguna de estas categorías: <b>fertilizantes</b>, <b>herramientas</b> o <b>abonos</b>.
            </div>
        <?php endif; ?>
    </div>
    <?php return ob_get_clean();
}

// ========================================================================
// 9. SHORTCODE: DASHBOARD (NAVEGACIÓN SPA)
// ========================================================================
add_shortcode( 'origen_special_dashboard', 'origen_special_dashboard_html' );
function origen_special_dashboard_html() {
    $current_user = wp_get_current_user();
    $role = empty($current_user->roles) ? '' : $current_user->roles[0];
    
    $cedula = get_user_meta( $current_user->ID, 'cedula_cafetera', true );
    $num_tarjeta = $cedula ? str_pad($cedula, 12, "0", STR_PAD_LEFT) : str_pad($current_user->ID, 12, "0", STR_PAD_LEFT);
    $num_formateado = chunk_split($num_tarjeta, 4, ' ');
    $vencimiento = date( 'm/y', strtotime( '+3 years', strtotime( $current_user->user_registered ) ) );

    ob_start(); ?>
    <div class="origen-dashboard">
        
        <div id="origen-view-home" class="origen-main-view">
            <div class="dash-header-user">
                <div class="avatar"><i class="ph ph-user"></i></div>
                <div>
                    <h2>Hola, <?php echo esc_html( $current_user->first_name ); ?></h2>
                    <span class="badge-role"><?php echo esc_html( translate_user_role( wp_roles()->roles[ $role ]['name'] ) ); ?></span>
                </div>
            </div>
            
            <div class="origen-grid">
                <?php if($role === 'caficultor'): ?>
                    <button class="origen-card-btn nav-trigger" data-target="origen-view-finca">
                        <i class="ph ph-plant"></i> Mi Finca / Cultivo
                    </button>
                    <button class="origen-card-btn nav-trigger" data-target="origen-view-produccion">
                        <i class="ph ph-calculator"></i> Proyección Cosecha
                    </button>
                    <button class="origen-card-btn nav-trigger" data-target="origen-view-tienda">
                        <i class="ph ph-storefront"></i> Tienda Agro
                    </button>
                <?php endif; ?>
                
                <?php if ( class_exists( 'WooCommerce' ) ): ?>
                    <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="origen-card-btn">
                        <i class="ph ph-shopping-cart"></i> Ver mi Carrito
                    </a>
                <?php endif; ?>
                
                <a href="<?php echo esc_url( wp_logout_url( site_url( '/caficultores' ) ) ); ?>" class="origen-btn-outline">
                    <i class="ph ph-sign-out"></i> Cerrar Sesión
                </a>
            </div>
        </div>

        <div id="origen-view-finca" class="origen-main-view" style="display: none;">
            <button class="origen-back-btn nav-trigger" data-target="origen-view-home"><i class="ph ph-arrow-left"></i> Volver al Inicio</button>
            <?php if($role === 'caficultor'): ?>
            <div class="origen-id-card">
                <div class="card-header-id"><span>Origen SPECIAL</span><i class="ph ph-contactless-payment"></i></div>
                <div class="card-chip"><div class="chip-inner"></div></div>
                <div class="card-number"><?php echo esc_html( trim($num_formateado) ); ?></div>
                <div class="card-footer-id">
                    <div class="card-name"><small>CAFICULTOR ASOCIADO</small><div><?php echo esc_html( strtoupper($current_user->display_name) ); ?></div></div>
                    <div class="card-exp"><small>VENCE</small><div><?php echo esc_html( $vencimiento ); ?></div></div>
                </div>
            </div>
            <?php endif; ?>
            <div class="view-header"><h3><i class="ph ph-plant"></i> Perfil de Finca</h3><p>Mantén los datos actualizados.</p></div>
            <?php echo do_shortcode('[origen_special_finca]'); ?>
        </div>

        <div id="origen-view-produccion" class="origen-main-view" style="display: none;">
            <button class="origen-back-btn nav-trigger" data-target="origen-view-home"><i class="ph ph-arrow-left"></i> Volver al Inicio</button>
            <div class="view-header"><h3><i class="ph ph-calculator"></i> Motor de Producción</h3><p>Calcula el potencial de tu cosecha.</p></div>
            <?php echo do_shortcode('[origen_special_produccion]'); ?>
        </div>

        <div id="origen-view-tienda" class="origen-main-view" style="display: none;">
            <button class="origen-back-btn nav-trigger" data-target="origen-view-home"><i class="ph ph-arrow-left"></i> Volver al Inicio</button>
            <div class="view-header"><h3><i class="ph ph-storefront"></i> Tienda Especializada</h3><p>Insumos agrícolas con descuento exclusivo.</p></div>
            <?php echo do_shortcode('[origen_special_tienda]'); ?>
        </div>

    </div>
    <?php return ob_get_clean();
}

// ========================================================================
// 10. LÓGICAS AJAX
// ========================================================================
add_action( 'wp_ajax_nopriv_origen_register_action', 'origen_ajax_register' ); 
add_action( 'wp_ajax_origen_register_action', 'origen_ajax_register' );
function origen_ajax_register() {
    check_ajax_referer( 'origen_auth_nonce', 'nonce' ); 
    
    $email = sanitize_email( $_POST['email'] ); 
    $pass = $_POST['pass']; 
    $role = sanitize_text_field($_POST['role']);
    
    if ( email_exists( $email ) ) {
        wp_send_json_error( 'El correo ya está registrado.' );
    }
    
    $user_id = wp_insert_user( array( 
        'user_login' => $email, 
        'user_pass' => $pass, 
        'user_email' => $email, 
        'first_name' => sanitize_text_field( $_POST['name'] ), 
        'last_name' => sanitize_text_field( $_POST['lastname'] ), 
        'display_name' => sanitize_text_field( $_POST['name'] ) . ' ' . sanitize_text_field( $_POST['lastname'] ), 
        'role' => $role 
    ) );
    
    if ( is_wp_error( $user_id ) ) {
        wp_send_json_error( $user_id->get_error_message() );
    }
    
    add_user_meta( $user_id, 'cedula_cafetera', sanitize_text_field( $_POST['id_number'] ) ); 
    add_user_meta( $user_id, 'departamento', sanitize_text_field( $_POST['depto'] ) ); 
    add_user_meta( $user_id, 'municipio', sanitize_text_field( $_POST['muni'] ) );
    
    if($role === 'caficultor') { 
        add_user_meta( $user_id, 'nombre_finca', sanitize_text_field( $_POST['finca'] ) ); 
        add_user_meta( $user_id, 'tamano_productor', sanitize_text_field( $_POST['tamano_prod'] ) ); 
    } elseif ($role === 'asociacion_cafe') { 
        add_user_meta( $user_id, 'nombre_asociacion', sanitize_text_field( $_POST['asoc_lista'] === 'otra' ? $_POST['asoc_otra'] : $_POST['asoc_lista'] ) ); 
    } elseif ($role === 'comprador_cafe') { 
        add_user_meta( $user_id, 'tipo_comprador', sanitize_text_field( $_POST['tipo_comprador'] ) ); 
    }
    
    wp_set_current_user( $user_id ); 
    wp_set_auth_cookie( $user_id, true ); 
    wp_send_json_success( 'OK' );
}

add_action( 'wp_ajax_nopriv_origen_login_action', 'origen_ajax_login' ); 
add_action( 'wp_ajax_origen_login_action', 'origen_ajax_login' );
function origen_ajax_login() { 
    check_ajax_referer( 'origen_auth_nonce', 'nonce' ); 
    $creds = array( 
        'user_login' => sanitize_text_field( $_POST['user'] ), 
        'user_password' => $_POST['pass'], 
        'remember' => true 
    ); 
    
    $user_signon = wp_signon( $creds, false ); 
    if ( is_wp_error( $user_signon ) ) {
        wp_send_json_error( 'Error de credenciales.' ); 
    }
    
    wp_send_json_success( 'OK' ); 
}

add_action( 'wp_ajax_origen_save_finca_action', 'origen_ajax_save_finca' );
function origen_ajax_save_finca() {
    check_ajax_referer( 'origen_auth_nonce', 'nonce' ); 
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( 'Sesión caducada.' );
    }
    
    global $wpdb; 
    $user_id = get_current_user_id(); 
    $table_name = $wpdb->prefix . 'origen_fincas';
    
    $data = array( 
        'user_id' => $user_id, 
        'nombre_finca' => sanitize_text_field( $_POST['f_nombre'] ), 
        'ubicacion' => sanitize_text_field( $_POST['f_ubicacion'] ), 
        'altura' => intval( $_POST['f_altura'] ), 
        'hectareas' => floatval( $_POST['f_hectareas'] ), 
        'cantidad_plantas' => intval( $_POST['f_plantas'] ), 
        'variedad_cafe' => sanitize_text_field( $_POST['f_variedad'] ), 
        'edad_cultivo' => intval( $_POST['f_edad'] ), 
        'densidad_siembra' => intval( $_POST['f_densidad'] ), 
        'tipo_sombra' => sanitize_text_field( $_POST['f_sombra'] ), 
        'sistema_cultivo' => sanitize_text_field( $_POST['f_sistema'] ) 
    );
    
    $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table_name WHERE user_id = %d", $user_id ) );
    
    if ( $exists ) { 
        $wpdb->update( $table_name, $data, array( 'id' => $exists ) ); 
    } else { 
        $wpdb->insert( $table_name, $data ); 
    }
    
    wp_send_json_success( '¡Datos de finca guardados!' );
}

add_action( 'wp_ajax_origen_calculate_production', 'origen_ajax_calculate_production' );
function origen_ajax_calculate_production() {
    check_ajax_referer( 'origen_auth_nonce', 'nonce' ); 
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( 'Sesión caducada.' );
    }
    
    global $wpdb; 
    $user_id = get_current_user_id(); 
    $table_name = $wpdb->prefix . 'origen_fincas';
    $finca = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE user_id = %d", $user_id ) );
    
    if( !$finca || empty($finca->cantidad_plantas) ) {
        wp_send_json_error( 'Aún no has guardado los datos de tu finca.' );
    }

    $precio_actual = get_precio_cafe_actual(); 
    $clima_actual = get_clima_finca( $finca->ubicacion );

    $plantas = (int) $finca->cantidad_plantas; 
    $edad = (int) $finca->edad_cultivo; 
    $sistema = $finca->sistema_cultivo; 
    $variedad = $finca->variedad_cafe; 
    $hectareas = (float) $finca->hectareas;
    
    $rendimiento_base = 0.8; 
    $ajuste_edad = ($edad <= 2) ? 0 : (($edad <= 5) ? 0.7 : 1.0);
    $ajuste_sistema = ($sistema === 'Tecnificado') ? 1.0 : (($sistema === 'Orgánico') ? 0.9 : 0.8);
    $ajuste_variedad = in_array($variedad, ['Castillo', 'Colombia']) ? 1.0 : ($variedad === 'Caturra' ? 0.9 : 0.85);

    $produccion_kg = $plantas * $rendimiento_base * $ajuste_edad * $ajuste_sistema * $ajuste_variedad;
    $sacos = $produccion_kg / 60; 
    $valor_total = $produccion_kg * $precio_actual; 
    $rendimiento_ha = $hectareas > 0 ? ($produccion_kg / $hectareas) : 0;
    
    $indicador = 'Bajo'; $color = '#ef4444'; $porcentaje = 25; 
    
    if ($produccion_kg == 0) { 
        $indicador = 'Cultivo Joven'; $color = '#94a3b8'; $porcentaje = 5; 
    } elseif ($rendimiento_ha >= 2500) { 
        $indicador = 'Alto (Óptimo)'; $color = '#10b981'; $porcentaje = 95; 
    } elseif ($rendimiento_ha >= 1000) { 
        $indicador = 'Medio (Promedio)'; $color = '#eab308'; $porcentaje = 60; 
    }

    wp_send_json_success( array( 
        'kg'         => number_format($produccion_kg, 1, ',', '.'), 
        'sacos'      => number_format($sacos, 1, ',', '.'), 
        'valor'      => number_format($valor_total, 0, ',', '.'), 
        'indicador'  => $indicador, 
        'color'      => $color, 
        'porcentaje' => $porcentaje, 
        'clima'      => $clima_actual 
    ) );
}

// ========================================================================
// 11. PANEL DE ADMINISTRACIÓN
// ========================================================================
add_action( 'admin_menu', 'origen_special_admin_menu' );
function origen_special_admin_menu() { 
    add_menu_page( 'Origen SPECIAL', 'Origen SPECIAL', 'manage_options', 'origen-special-users', 'origen_special_admin_page', 'dashicons-leaf', 30 ); 
}

function origen_special_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $users = get_users( array( 'role__in' => array( 'caficultor', 'asociacion_cafe', 'comprador_cafe' ), 'orderby' => 'registered', 'order' => 'DESC' ) );
    ?>
    <div class="wrap">
        <h1>Configuración y Gestión Origen SPECIAL</h1>
        
        <div style="background:#fff; padding:20px; border:1px solid #ccd0d4; margin: 20px 0; border-radius:5px;">
            <h2>⚙️ Conexión de APIs y Tienda WooCommerce</h2>
            <form method="post" action="options.php">
                <?php settings_fields( 'origen_special_settings_group' ); do_settings_sections( 'origen_special_settings_group' ); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Descuento Tienda (%)<br><small>Descuento aplicado en WooCommerce para rol Caficultor.</small></th>
                        <td><input type="number" name="origen_descuento_caficultor" value="<?php echo esc_attr( get_option('origen_descuento_caficultor', 10) ); ?>" /> %</td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Precio Base Café (COP/kg)<br><small>Fallback si falla la API de mercado.</small></th>
                        <td><input type="number" name="origen_precio_manual" value="<?php echo esc_attr( get_option('origen_precio_manual', 12000) ); ?>" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">OpenWeatherMap API Key<br><small>Llave para el clima de las fincas.</small></th>
                        <td><input type="text" name="origen_owm_api_key" style="width:350px;" value="<?php echo esc_attr( get_option('origen_owm_api_key') ); ?>" /></td>
                    </tr>
                </table>
                <?php submit_button('Guardar Configuración'); ?>
            </form>
        </div>

        <h2>👥 Usuarios Registrados</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Nombre</th><th>Cédula</th><th>Rol</th><th>Email</th></tr></thead>
            <tbody>
                <?php foreach ( $users as $user ) { 
                    echo '<tr>';
                    echo '<td>' . esc_html( $user->first_name . ' ' . $user->last_name ) . '</td>';
                    echo '<td>' . esc_html( get_user_meta( $user->ID, 'cedula_cafetera', true ) ) . '</td>';
                    echo '<td>' . esc_html( ucfirst( current( $user->roles ) ) ) . '</td>';
                    echo '<td>' . esc_html( $user->user_email ) . '</td>';
                    echo '</tr>'; 
                } ?>
            </tbody>
        </table>
    </div>
    <?php
}